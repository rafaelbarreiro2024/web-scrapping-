// scrapper_vea.js
// Scraper de Vea:
//   1) Descuentos bancarios: los vigentes de Vea, agrupados por banco.
//   2) Sucursales: descarga todas desde la API de Vea y deja las de la provincia que elija el usuario.
//   3) Historias (Storyly) de la home: un solo registro por historia (grupo).
// Salida: data/descuentos_bancarios.json, data/sucursales.json y data/historias.json
// Uso: node scrapper_vea.js

const fs = require('fs');
const readline = require('readline');

let puppeteer;
try {
  puppeteer = require('puppeteer');
} catch {
  puppeteer = require('puppeteer-core');
}

const URL_VEA = 'https://www.vea.com.ar/';

// Dirección de la API de Storyly que usa la home de Vea (se usa solo si no se logra capturar la original)
const URL_STORYLY_RESPALDO =
  'https://api.storyly.io/web/v4.3/placement/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NfaWQiOjE0NTgwLCJhcHBfaWQiOjIzMTA3LCJwbGNtbnRfaWQiOjI3NDk4LCJzZGtfcGwiOiJ3ZWIifQ.vGmjb_4XaICgeBXnByrGZgvlnvNuvsSKTrnaQ5vSZus';
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

// Descuentos: la API trae las promociones de varias marcas de Cencosud (Jumbo, Disco, Vea).
const SITIO_VEA = 'veaargentina'; // solo se dejan las que aplican a Vea
const SOLO_VIGENTES = true; // true: deja solo las que están vigentes hoy; false: trae todas

// Navegador: false = trabaja en segundo plano (no se ve ni molesta); true = abre la ventana
const MOSTRAR_NAVEGADOR = false;
const DIAS = {
  0: 'Domingo',
  1: 'Lunes',
  2: 'Martes',
  3: 'Miércoles',
  4: 'Jueves',
  5: 'Viernes',
  6: 'Sábado',
  7: 'Domingo',
};

const preguntar = (texto) =>
  new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(texto, (respuesta) => {
      rl.close();
      resolve(respuesta.trim());
    });
  });

// Saca tildes y pasa a mayúsculas para comparar textos
const normalizar = (t) =>
  String(t ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toUpperCase();

// Si usás puppeteer-core necesita la ruta de Chrome o Edge.
// Si ya tenías tu propia ruta, ponela acá en CHROME_PATH.
const CHROME_PATH = process.env.CHROME_PATH || null;
const RUTAS_CHROME = [
  CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
].filter(Boolean);

// Campos que pide la propia página de sucursales de Vea
const CAMPOS_SUCURSALES =
  'name,grouping,image_maps,geocoordinates,SellerName,id,country,city,neighborhood,number,postalCode,state,street,schedule,services,paymentMethods,opening,hasPickup,hasDelivery,address,url_image,phone';

// ---------- Texto legible: true -> "Sí", false -> "No", null o vacío -> "No hay" ----------
function aTextoLegible(valor) {
  if (valor === true) return 'Sí';
  if (valor === false) return 'No';
  if (valor === null || valor === undefined) return 'No hay';
  if (typeof valor === 'string') return valor.trim() === '' ? 'No hay' : valor;
  if (Array.isArray(valor)) return valor.length ? valor.map(aTextoLegible) : 'No hay';
  if (typeof valor === 'object') {
    return Object.fromEntries(Object.entries(valor).map(([k, v]) => [k, aTextoLegible(v)]));
  }
  return valor;
}

// ---------- Descuentos bancarios ----------
const fechaDesdeSegundos = (segundos) => {
  const n = Number(segundos);
  if (!Number.isFinite(n) || n <= 0) return null;
  return new Date(n * 1000).toLocaleDateString('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
};

// Deja los saltos de línea y saca tabulaciones y espacios de más
const limpiarTexto = (t) => {
  if (!t) return null;
  const limpio = String(t)
    .replace(/\r\n/g, '\n')
    .replace(/[\t ]+/g, ' ')
    .replace(/ ?\n ?/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return limpio || null;
};

function normalizarDescuento(d) {
  const numero = parseFloat(d.discount);
  const textoNumero = Number.isFinite(numero) ? String(numero) : null;
  const textoExtra = (d.discountText ?? '').trim();
  const esCuotas = textoExtra !== ''; // sin texto extra es un porcentaje de descuento

  let beneficio = null;
  if (textoNumero !== null) {
    beneficio = esCuotas ? `${textoNumero} ${textoExtra}` : `${textoNumero}%`;
  }

  const sucursales = (d.stores || []).map((s) => String(s.name ?? s).trim()).filter(Boolean);
  const excluidas = (d.excludedStores || []).map((s) => String(s.name ?? s).trim()).filter(Boolean);

  return {
    tipo: esCuotas ? 'Cuotas sin interés' : 'Descuento',
    beneficio,
    detalle: (d.installmentsText ?? '').trim() || null,
    dias: (d.days || []).map((n) => DIAS[Number(n)]).filter(Boolean),
    vigencia_desde: fechaDesdeSegundos(d.dateStart),
    vigencia_hasta: fechaDesdeSegundos(d.dateEnd),
    medios_de_pago: Object.keys(d.paymentMethod || {}),
    condiciones: limpiarTexto(d.info),
    terminos_y_condiciones: limpiarTexto(d.legals),
    sucursales_incluidas: sucursales.length ? sucursales : 'Todas',
    sucursales_excluidas: excluidas,
  };
}

function armarDescuentosPorBanco(crudos) {
  const ahora = Date.now() / 1000;

  const filtrados = crudos.filter((d) => {
    if (!(d.websites || []).includes(SITIO_VEA)) return false;
    if (!SOLO_VIGENTES) return true;
    const desde = Number(d.dateStart) || 0;
    const hasta = Number(d.dateEnd) || Infinity;
    return desde <= ahora && ahora <= hasta;
  });

  const porBanco = new Map();
  for (const d of filtrados) {
    const promo = normalizarDescuento(d);
    const bancos = d.banks && d.banks.length ? d.banks : [{ name: null }];

    for (const b of bancos) {
      const nombre = (b.name ?? '').trim() || 'Sin banco';
      if (!porBanco.has(nombre)) {
        porBanco.set(nombre, {
          banco: nombre,
          imagen: b.image ?? null,
          orden: Number(b.order) || 999,
          promociones: [],
        });
      }
      porBanco.get(nombre).promociones.push(promo);
    }
  }

  return {
    totalVigentes: filtrados.length,
    bancos: [...porBanco.values()]
      .sort((a, b) => a.orden - b.orden || a.banco.localeCompare(b.banco, 'es'))
      .map(({ orden, ...resto }) => ({ ...resto, cantidad_promociones: resto.promociones.length })),
  };
}

// ---------- Sucursales ----------
function normalizarSucursal(s) {
  const [lat, lng] = String(s.geocoordinates ?? '')
    .split(',')
    .map((n) => parseFloat(n));

  return {
    id: s.id,
    nombre: s.name ?? null,
    provincia: s.state ?? null,
    agrupacion: s.grouping ?? null,
    direccion: s.address ?? null,
    codigo_postal: s.postalCode ?? null,
    telefono: s.phone ?? null,
    horarios: s.schedule ?? null,
    servicios: s.services
      ? s.services
          .split('/')
          .map((x) => x.trim())
          .filter(Boolean)
      : [],
    medios_de_pago: s.paymentMethods ?? null, // texto tal cual lo manda Vea
    retiro_en_tienda: s.hasPickup ?? null,
    envio_a_domicilio: s.hasDelivery ?? null,
    coordenadas: Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : null,
    seller: s.SellerName ?? null,
    imagen: s.url_image ?? null,
  };
}

async function elegirProvincia(sucursales) {
  const conteo = new Map();
  for (const s of sucursales) {
    conteo.set(s.provincia, (conteo.get(s.provincia) || 0) + 1);
  }
  const provincias = [...conteo.keys()].filter(Boolean).sort((a, b) => a.localeCompare(b, 'es'));

  console.log('\nProvincias disponibles:');
  console.log('  0) TODAS');
  provincias.forEach((p, i) => console.log(`  ${i + 1}) ${p} (${conteo.get(p)} sucursales)`));

  while (true) {
    const respuesta = await preguntar('\nElegí una provincia (número o nombre): ');
    const texto = normalizar(respuesta);

    if (respuesta === '0' || texto === 'TODAS') {
      return { nombre: 'TODAS', lista: sucursales };
    }

    const alias = texto === 'CABA' ? 'CAPITAL FEDERAL' : texto;
    const elegida = provincias[Number(respuesta) - 1] ?? provincias.find((p) => normalizar(p) === alias);

    if (elegida) {
      return { nombre: elegida, lista: sucursales.filter((s) => s.provincia === elegida) };
    }
    console.log('No reconocí esa opción, probá de nuevo.');
  }
}

// ---------- Historias: armado del JSON a partir de la API de Storyly ----------
function extraerHistorias(respuesta) {
  const grupos = [];

  for (const widget of respuesta.widgets || []) {
    for (const g of widget.w_content?.story_groups || []) {
      const historias = g.stories || [];
      const unicos = (lista) => [...new Set(lista.filter(Boolean))];
      const capasPrincipales = historias.map((s) =>
        (s.media?.layers || []).find((c) => c.studio_component_type === 'studio_main_layer')
      );
      const botones = historias.map((s) => (s.media?.layers || []).find((c) => c.outlink));

      // Un solo registro por historia (grupo), con todo junto
      grupos.push({
        grupo_id: g.group_id,
        titulo: g.title ?? g.name ?? null,
        icono: g.icon_image_url ?? g.icon_thumbnail_url ?? null,
        icono_video: g.icon_video_url ?? null,
        cantidad_imagenes_o_videos: historias.length,
        imagenes: unicos(capasPrincipales.map((c) => c?.image_url)),
        videos: unicos(capasPrincipales.map((c) => c?.video_url)),
        vistas_previas: unicos(historias.map((s) => s.preview_url)),
        textos_boton: unicos(botones.map((b) => b?.button_text)),
        links: unicos(botones.map((b) => b?.outlink)),
      });
    }
  }
  return grupos;
}

// ---------- Historias: obtener la respuesta de Storyly con reintentos ----------
const tieneGrupos = (data) =>
  (data?.widgets || []).some((w) => (w.w_content?.story_groups || []).length > 0);

async function obtenerRespuestaStoryly(page, capturas, estado) {
  const buscar = () => capturas.map((c) => c.data).find(tieneGrupos) ?? null;

  for (let intento = 1; intento <= 3; intento++) {
    // Esperar hasta 20 s a que llegue, bajando de a poco por si la carga se activa al hacer scroll
    const t0 = Date.now();
    while (!buscar() && Date.now() - t0 < 20000) {
      const y = Math.floor((Date.now() - t0) / 5000) * 300;
      await page.evaluate((pos) => window.scrollTo(0, pos), y).catch(() => {});
      await esperar(500);
    }
    if (buscar()) return buscar();

    // Pedirla directo desde la página
    const url = estado.url || URL_STORYLY_RESPALDO;
    try {
      const data = await page.evaluate(async (u) => {
        const res = await fetch(u);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json();
      }, url);
      if (tieneGrupos(data)) return data;
    } catch {
      // se sigue con el reintento
    }

    if (intento < 3) {
      console.log(`Historias: intento ${intento} sin datos, recargo la página...`);
      await page.reload({ waitUntil: 'domcontentloaded', timeout: 90000 }).catch(() => {});
    }
  }
  return null;
}

// ---------- Programa principal ----------
(async () => {
  const opciones = MOSTRAR_NAVEGADOR
    ? { headless: false, defaultViewport: null, args: ['--start-maximized'] }
    : { headless: true, defaultViewport: { width: 1366, height: 768 } };
  const chromePath = RUTAS_CHROME.find((r) => fs.existsSync(r));
  if (chromePath) opciones.executablePath = chromePath;

  const browser = await puppeteer.launch(opciones);
  const page = await browser.newPage();

  await page.setUserAgent(
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
  );

  // Capturar la dirección y las respuestas JSON de Storyly mientras carga la página
  const capturas = [];
  const estadoStoryly = { url: null };

  page.on('request', (req) => {
    const url = req.url();
    if (/api\.storyly\.io\/web\/[^/]+\/placement\//i.test(url)) estadoStoryly.url = url;
  });

  page.on('response', async (res) => {
    const url = res.url();
    if (!/storyly/i.test(url)) return;
    const tipo = res.headers()['content-type'] || '';
    if (!tipo.includes('json')) return;
    try {
      capturas.push({ url, data: JSON.parse(await res.text()) });
    } catch {
      // respuesta sin cuerpo disponible, se ignora
    }
  });

  try {
    await page.goto(URL_VEA, { waitUntil: 'domcontentloaded', timeout: 90000 });
    fs.mkdirSync('data', { recursive: true });

    // 1) Descuentos bancarios: se piden desde la propia página (mismo origen)
    let descuentos = null;
    try {
      const textoDescuentos = await page.evaluate(async () => {
        const res = await fetch('/api/dataentities/JN/documents/bankDiscount?_fields=value,id&an=jumboargentina', {
          headers: { Accept: 'application/json' },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status} al pedir los descuentos`);
        const json = await res.json();
        return json.value; // viene como texto JSON dentro del JSON
      });
      const crudos = JSON.parse(textoDescuentos);
      const { totalVigentes, bancos } = armarDescuentosPorBanco(crudos);
      descuentos = {
        supermercado: 'Vea',
        fecha_consulta: fechaDesdeSegundos(Date.now() / 1000),
        solo_vigentes: SOLO_VIGENTES,
        cantidad_bancos: bancos.length,
        cantidad_promociones: totalVigentes,
        bancos,
      };
      console.log(
        `Descuentos bancarios: ${totalVigentes} promociones de Vea (de ${crudos.length} en total), ${bancos.length} bancos`
      );
    } catch (err) {
      console.error('No se pudieron obtener los descuentos bancarios:', err.message);
    }

    // 2) Sucursales: se piden desde la propia página (mismo origen), de a 100 por pedido
    const crudas = await page.evaluate(async (campos) => {
      const vistas = new Map();
      const tamano = 100;

      for (let desde = 0; desde < 5000; desde += tamano) {
        const url = `/api/dataentities/NT/search?_fields=${campos}&_where=isActive=true&_sort=name%20ASC`;
        const res = await fetch(url, {
          headers: { 'REST-Range': `resources=${desde}-${desde + tamano - 1}`, Accept: 'application/json' },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status} al pedir las sucursales`);

        const lote = await res.json();
        const antes = vistas.size;
        for (const s of lote) vistas.set(s.id, s);

        const rango = res.headers.get('rest-content-range') || ''; // ej: "resources 0-99/187"
        const total = Number(rango.split('/')[1]) || null;

        if (lote.length < tamano) break; // último lote
        if (total && desde + tamano >= total) break; // ya está todo
        if (vistas.size === antes) break; // no vino nada nuevo
      }
      return [...vistas.values()];
    }, CAMPOS_SUCURSALES);

    const todas = crudas.map(normalizarSucursal);
    console.log(`Sucursales descargadas: ${todas.length}`);

    const { nombre, lista } = await elegirProvincia(todas);

    // 3) Historias: con reintentos, porque a veces la API de Storyly tarda o no llega
    const respuestaStoryly = await obtenerRespuestaStoryly(page, capturas, estadoStoryly);
    const historias = respuestaStoryly ? extraerHistorias(respuestaStoryly) : [];

    // 4) Guardar resultados
    if (descuentos) {
      fs.writeFileSync('data/descuentos_bancarios.json', JSON.stringify(aTextoLegible(descuentos), null, 2));
    }
    fs.writeFileSync(
      'data/sucursales.json',
      JSON.stringify(
        { provincia: nombre, cantidad: lista.length, sucursales: lista.map(aTextoLegible) },
        null,
        2
      )
    );
    if (historias.length) {
      fs.writeFileSync('data/historias.json', JSON.stringify(historias.map(aTextoLegible), null, 2));
    } else {
      // Se deja el archivo anterior y se guarda lo capturado para poder revisarlo
      fs.writeFileSync('data/stories_red.json', JSON.stringify(capturas, null, 2));
      console.log(
        'No se pudieron obtener las historias: se mantiene el data/historias.json anterior y se guardó data/stories_red.json para revisar.'
      );
    }

    console.log('\nListo:');
    if (descuentos) console.log(`  Descuentos bancarios -> data/descuentos_bancarios.json`);
    console.log(`  Sucursales de ${nombre}: ${lista.length} -> data/sucursales.json`);
    if (historias.length) console.log(`  Grupos de historias: ${historias.length} -> data/historias.json`);
  } catch (err) {
    console.error('Error en el scraper:', err.message);
  } finally {
    await browser.close();
  }
})();