// ============================================================
// CAPTURAR PANTALLA
// ============================================================
// Abre beneficios.galicia.ar directo (sin el iframe de galicia.ar),
// vos navegás a mano hasta la pantalla que quieras, y cada vez que
// apretás Enter en la consola se guarda el HTML de esa pantalla en
// data/capturas/.
//
// Guarda solo el <main> (el contenido real), sin scripts, así no
// incluye CSS gigante ni datos de sesión.
// ============================================================

const puppeteer = require("puppeteer");
const readline = require("readline");
const fs = require("fs");
const path = require("path");

const URL_LISTADO = "https://beneficios.galicia.ar/filtro/8%7Csupermercados";
const CARPETA = path.join(__dirname, "data", "capturas");

async function htmlDeLaPantalla(page) {
    return page.evaluate(() => {
        const base = document.querySelector("main") || document.body;
        const copia = base.cloneNode(true);

        copia.querySelectorAll("script, style, noscript").forEach(n => n.remove());

        return copia.outerHTML;
    });
}

// Body completo, sin scripts ni estilos. Sirve para ver listas desplegables
// que la página dibuja FUERA del <main>.
async function htmlCompleto(page) {
    return page.evaluate(() => {
        const copia = document.body.cloneNode(true);
        copia.querySelectorAll("script, style, noscript").forEach(n => n.remove());
        return copia.outerHTML;
    });
}

async function main() {
    fs.mkdirSync(CARPETA, { recursive: true });

    const browser = await puppeteer.launch({
        headless: false,
        defaultViewport: { width: 1366, height: 900 }
    });

    const page = await browser.newPage();
    await page.goto(URL_LISTADO, { waitUntil: "networkidle2", timeout: 60000 });

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    const preguntar = texto =>
        new Promise(resolve => rl.question(texto, resolve));

    console.log("\nNavegá en el navegador que se abrió hasta la pantalla que quieras guardar.");
    console.log("Expandí lo que se pueda desplegar antes de guardar.\n");

    let numero = 1;

    while (true) {
        const respuesta = (await preguntar(
            "Enter = guardar esta pantalla (podés escribir un nombre), q = salir: "
        )).trim();

        if (respuesta.toLowerCase() === "q") break;

        const nombre = respuesta.replace(/[^\w\-]+/g, "_") || "pantalla";
        const archivo = path.join(
            CARPETA,
            `${String(numero).padStart(2, "0")}_${nombre}.html`
        );

        const html = await htmlDeLaPantalla(page);

        fs.writeFileSync(
            archivo,
            `<!-- URL: ${page.url()} -->\n${html}`,
            "utf8"
        );

        const archivoCompleto = archivo.replace(/\.html$/, "_completo.html");
        const completo = await htmlCompleto(page);

        fs.writeFileSync(
            archivoCompleto,
            `<!-- URL: ${page.url()} -->\n${completo}`,
            "utf8"
        );

        console.log(`Guardado: ${archivo} (${Math.round(html.length / 1024)} KB)`);
        console.log(`Guardado: ${archivoCompleto} (${Math.round(completo.length / 1024)} KB)`);
        numero++;
    }

    rl.close();
    await browser.close();
}

main();