// ============================================================
// SCRAPER BENEFICIOS GALICIA - SUPERMERCADOS
// ============================================================
// Versión para la página NUEVA de beneficios.galicia.ar.
//
// Qué hace:
//   1. Recorre el listado de supermercados (catalogo?...&page=N).
//   2. Entra a cada promoción y lee beneficio, días, vigencia, tope, medios de
//      pago y términos y condiciones.
//   3. Entra a "Mostrar todos los comercios" y lee los locales adheridos,
//      filtrando por la provincia / localidad que se elija.
//   4. Guarda los resultados en la carpeta data/ y cierra el navegador.
//
// Cómo ejecutarlo (desde la carpeta del proyecto):
//   npm install puppeteer
//   node index.js                                                  (pregunta la zona)
//   node index.js "--provincia=Buenos Aires"                       (toda la provincia)
//   node index.js "--provincia=Buenos Aires" "--localidad=Munro"   (una localidad)
//
// Salida: data/promociones_terminos_y_condiciones.json
//         data/sucursales.json
// ============================================================

const puppeteer = require("puppeteer");
const fs = require("fs");
const path = require("path");
const readline = require("readline");


// ------------------------------------------------------------
// CONFIGURACIÓN
// ------------------------------------------------------------

const ORIGEN = "https://beneficios.galicia.ar";

// Listado de supermercados (categoría 8). La paginación va en el parámetro "page".
const urlListado = pagina =>
    `${ORIGEN}/catalogo?idcategoria=8&titulo=supermercados&criteriodeorden=cuotas&page=${pagina}`;

// Tope de seguridad de páginas del listado.
const MAX_PAGINAS_LISTADO = 200;

// true  = además de la promoción, entra a "Mostrar todos los comercios" y lee los locales.
// false = no lee sucursales (tampoco pregunta la zona).
const LEER_SUCURSALES = true;

// Tope de páginas de locales por promoción (8 locales por página).
const MAX_PAGINAS_SUCURSALES = 100;

// Con una zona elegida (provincia / localidad):
//   true  = solo se guardan los supermercados y promociones que tienen al menos
//           un local en esa zona. Los demás no se guardan. Las promociones de las
//           que no se pudo confirmar (online, sin sección de locales o con error)
//           tampoco.
//   false = se guardan todos, marcados con tiene_sucursal_en_la_zona ("si" / "no" / "sin datos").
// Sin zona elegida este interruptor no hace nada.
const SOLO_SUPERMERCADOS_EN_LA_ZONA = true;

// true  = al terminar (o si falla), cierra el navegador y el programa.
// false = deja el navegador abierto para inspeccionarlo.
const CERRAR_AL_TERMINAR = true;

// true = además guarda data/crudo.json con todo lo leído, sin ordenar (para depurar).
const GUARDAR_CRUDO = false;

// true = muestra en consola los pasos del filtro de zona.
const DEPURAR_ZONA = true;

const CARPETA_DATA = path.join(__dirname, "data");
const ARCHIVO_PROMOCIONES = path.join(CARPETA_DATA, "promociones_terminos_y_condiciones.json");
const ARCHIVO_SUCURSALES = path.join(CARPETA_DATA, "sucursales.json");
const ARCHIVO_CRUDO = path.join(CARPETA_DATA, "crudo.json");

// Tarjetas del listado. Los carruseles ("También podría interesarte") se descartan
// dentro de leerTarjetas.
const SEL_TARJETA = '[aria-label="click en esta card para conocer más"]';
const SEL_ARTICULO = '[role="article"][aria-labelledby^="promotion-"]';


// ------------------------------------------------------------
// UTILIDADES
// ------------------------------------------------------------

const dormir = ms => new Promise(resolve => setTimeout(resolve, ms));
const pausaCorta = () => dormir(500 + Math.random() * 500);

// Sin tildes, en minúsculas y con los espacios unificados.
const normalizar = texto =>
    (texto || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();

// "[www.sitio.com](https://www.sitio.com)" -> "www.sitio.com"
const limpiarNombre = nombre =>
    (nombre || "").replace(/^\[(.+?)\]\(.*?\)$/, "$1").trim();

// Errores que indican que el navegador se cerró: no tiene sentido seguir.
const esErrorFatal = error =>
    /detached Frame|Target closed|Session closed|Connection closed|browser has disconnected|Protocol error/i
        .test((error && error.message) || "");

// Zona de sucursales que se quiere leer (se pregunta al iniciar).
// provincia vacía = sin filtro (lee TODAS las sucursales).
let ZONA = { provincia: "", localidad: "" };

const descripcionZona = () =>
    ZONA.localidad ? `${ZONA.localidad} (${ZONA.provincia})` : ZONA.provincia;

const logZona = (...partes) => {
    if (DEPURAR_ZONA) console.log("   [zona]", ...partes);
};

// Espera a que un valor (texto) deje de cambiar: dos lecturas iguales y no vacías.
async function esperarEstable(leerFirma, timeout = 10000) {
    const limite = Date.now() + timeout;
    let anterior = null;
    let repeticiones = 0;

    while (Date.now() < limite) {
        const actual = await leerFirma().catch(() => "");

        if (actual && actual === anterior) {
            repeticiones++;
            if (repeticiones >= 1) return actual;
        } else {
            repeticiones = 0;
        }

        anterior = actual;
        await dormir(350);
    }

    return anterior || "";
}

// Abre una URL. Si la página sigue cargando recursos externos (publicidad,
// estadísticas) no es un error: seguimos igual.
async function irA(page, url) {
    try {
        await page.goto(url, { waitUntil: "networkidle2", timeout: 60000 });
    } catch (error) {
        if (esErrorFatal(error)) throw error;
    }
}

const diagnosticosGuardados = new Set();

// Guarda una captura y el HTML de la pantalla en data/ (una vez por tipo de problema).
async function guardarDiagnostico(page, nombre) {
    if (diagnosticosGuardados.has(nombre)) return;
    diagnosticosGuardados.add(nombre);

    try {
        await page.screenshot({ path: path.join(CARPETA_DATA, `diagnostico_${nombre}.png`) });

        const html = await page.evaluate(() => {
            const copia = document.body.cloneNode(true);
            copia.querySelectorAll("script, style, noscript").forEach(n => n.remove());
            return copia.outerHTML;
        });

        fs.writeFileSync(path.join(CARPETA_DATA, `diagnostico_${nombre}.html`), html, "utf8");
    } catch (_) {
        // el diagnóstico es opcional
    }
}


// ------------------------------------------------------------
// FUNCIONES QUE SE EJECUTAN DENTRO DE LA PÁGINA
// ------------------------------------------------------------
// Deben ser autosuficientes (no pueden usar variables de afuera).

// Tarjetas del listado, sin las de los carruseles.
const leerTarjetas = selector => {
    const tarjetas = Array.from(document.querySelectorAll(selector))
        .filter(el => !el.closest(".slick-slide"));

    // Si dos tarjetas tienen el mismo texto, la clave las distingue por orden.
    const repetidas = {};

    return tarjetas.map((el, indice) => {
        const img = el.querySelector("img");
        const texto = (el.innerText || "").replace(/\s+/g, " ").trim();

        repetidas[texto] = (repetidas[texto] || 0) + 1;

        return {
            indice,
            nombre: img ? img.alt || "" : "",
            imagen: img ? img.src || "" : "",
            texto,
            clave: texto + "#" + repetidas[texto]
        };
    });
};

const obtenerTarjeta = (selector, indice) =>
    Array.from(document.querySelectorAll(selector))
        .filter(el => !el.closest(".slick-slide"))[indice] || null;

// Lee la pantalla de detalle de una promoción (/promocion/...).
const extraerPromocion = () => {
    const limpio = t => (t || "").replace(/\s+/g, " ").trim();

    const articulo = document.querySelector('[role="article"][aria-labelledby^="promotion-"]');
    if (!articulo) return null;

    const idTitulo = articulo.getAttribute("aria-labelledby") || "";
    const titulo = document.getElementById(idTitulo);
    const id = (idTitulo.match(/promotion-(\d+)-title/) || [])[1] || "";

    const logo = articulo.querySelector("img");
    const categoria = titulo && titulo.parentElement
        ? limpio((titulo.parentElement.querySelector("p") || {}).textContent)
        : "";

    const subtitulo = articulo.querySelector("h2");
    const resumen = subtitulo && subtitulo.parentElement
        ? subtitulo.parentElement.querySelector("p")
        : null;

    const seccion = nombre =>
        document.querySelector('section[aria-labelledby="promotion-' + nombre + '-title"]');

    const cuando = seccion("schedule");
    const pago = seccion("payment");
    const donde = seccion("availability");

    // ---- Días y vigencia ("Desde el 01/10/26 hasta el 31/12/26.") ----
    const completarAnio = f => {
        const m = f.match(/^(\d{2})\/(\d{2})\/(\d{2,4})$/);
        return m ? `${m[1]}/${m[2]}/${m[3].length === 2 ? "20" + m[3] : m[3]}` : f;
    };

    const dias = cuando
        ? Array.from(cuando.querySelectorAll('[aria-label="Días que aplica la promoción"] .chip span'))
            .map(s => limpio(s.textContent))
            .filter(Boolean)
        : [];

    const textoVigencia = cuando
        ? limpio(
            Array.from(cuando.querySelectorAll("p"))
                .map(p => limpio(p.textContent))
                .find(t => /^desde\b/i.test(t)) || ""
        )
        : "";

    const fechas = (textoVigencia.match(/\d{2}\/\d{2}\/\d{2,4}/g) || []).map(completarAnio);

    // ---- Cómo pagar ----
    const medios = [];
    let conQr = false;
    let comoPagar = "";

    if (pago) {
        comoPagar = limpio((pago.querySelector("span") || {}).textContent);

        const contenedor = pago.querySelector('[aria-label="Medios de pago habilitados"]');

        if (contenedor) {
            Array.from(contenedor.querySelectorAll("p")).forEach(p => {
                const tarjetas = Array.from((p.parentElement || p).querySelectorAll("img"))
                    .map(i => ({ nombre: i.alt || i.title || "", imagen: i.src || "" }))
                    .filter(t => t.imagen || t.nombre);

                medios.push({ tipo: limpio(p.textContent), tarjetas });
            });
        }

        conQr = /\bQR\b/.test(pago.textContent || "") ||
                !!pago.querySelector('img[src*="qrCode" i], img[alt*="QR" i]');
    }

    // ---- Dónde comprar ----
    let modalidad = "";
    let comercios = "";
    let tienda = "";

    if (donde) {
        modalidad = Array.from(donde.querySelectorAll("p"))
            .map(p => limpio(p.textContent))
            .find(t => /^(presencial|online)$/i.test(t)) || "";

        const enlaceComercios = donde.querySelector('a[href*="/comercios-adheridos/"]');
        if (enlaceComercios) {
            comercios = new URL(enlaceComercios.getAttribute("href"), location.origin).href;
        }

        const enlaceTienda = donde.querySelector('a[target="_blank"]');
        if (enlaceTienda) tienda = enlaceTienda.href;
    }

    // ---- Términos y condiciones ----
    let terminos = "";
    const cftea = {};
    const detalleTerminos = document.getElementById("promotion-terms");

    if (detalleTerminos) {
        const contenido = detalleTerminos.querySelector("summary + div");

        if (contenido) {
            // El texto legal es el texto propio del contenedor; el CFTEA va en bloques internos.
            const copia = contenido.cloneNode(true);
            copia.querySelectorAll("div, p").forEach(n => n.remove());
            terminos = limpio(copia.textContent);

            contenido.querySelectorAll("p").forEach(p => {
                const m = limpio(p.textContent).match(/CFTEA\s+(C\/IVA|S\/IVA)\s+([\d.,]+\s*%)/i);

                if (m) {
                    cftea[m[1].toUpperCase() === "C/IVA" ? "con_iva" : "sin_iva"] = m[2].replace(/\s+/g, "");
                }
            });
        }
    }

    // URL sin el parámetro de retorno: .../promocion/<id>|<marca>|marca
    const partes = location.href.split(/%7C|\|/i);
    const url = partes.length > 3 ? partes.slice(0, 3).join("%7C") : location.href;

    return {
        url,
        id_promocion: id,
        marca: titulo ? limpio(titulo.textContent) : "",
        logo: logo ? logo.src : "",
        categoria,
        beneficio: subtitulo ? limpio(subtitulo.textContent) : "",
        condiciones_resumen: resumen ? limpio(resumen.textContent) : "",
        dias,
        vigencia: { texto: textoVigencia, desde: fechas[0] || "", hasta: fechas[1] || "" },
        como_pagar: comoPagar,
        paga_con_qr: conQr,
        medios_de_pago: medios,
        modalidad,
        comercios_href: comercios,
        tienda_online: tienda,
        terminos_y_condiciones: terminos,
        cftea
    };
};

// ---- Pantalla "Comercios adheridos" (/comercios-adheridos/...) ----

// "01-07 de 07 resultados" + "01 de 01" + botones de página.
const leerPaginacionLocales = () => {
    const contenedor = document.querySelector('[aria-label="Paginación de comercios adheridos"]');
    const visibles = document.querySelectorAll('ul[aria-label="Comercios adheridos"] > li').length;

    if (!contenedor) return null;

    const texto = (contenedor.innerText || "").replace(/\s+/g, " ");
    const rango = texto.match(/(\d+)\s*-\s*(\d+)\s+de\s+(\d+)\s+resultado/i);

    const paginas = Array.from(contenedor.querySelectorAll("span"))
        .map(s => (s.textContent || "").trim().match(/^(\d+)\s+de\s+(\d+)$/))
        .find(Boolean);

    const siguiente = contenedor.querySelector('button[aria-label="Página siguiente"]');
    const anterior = contenedor.querySelector('button[aria-label="Página anterior"]');

    return {
        desde: rango ? parseInt(rango[1], 10) : null,
        hasta: rango ? parseInt(rango[2], 10) : null,
        total: rango ? parseInt(rango[3], 10) : null,
        pagina: paginas ? parseInt(paginas[1], 10) : null,
        paginas: paginas ? parseInt(paginas[2], 10) : null,
        hayMas: !!siguiente && !siguiente.disabled,
        hayAnterior: !!anterior && !anterior.disabled,
        visibles
    };
};

// Cada local: dirección y "LOCALIDAD, PROVINCIA".
const leerLocalesDeLista = () =>
    Array.from(document.querySelectorAll('ul[aria-label="Comercios adheridos"] > li'))
        .map(li => {
            const parrafos = Array.from(li.querySelectorAll("p"));
            const valor = p => (p ? (p.getAttribute("title") || p.textContent || "") : "").trim();

            const direccion = valor(parrafos[0]);
            const zona = valor(parrafos[1]);
            const coma = zona.lastIndexOf(",");

            return {
                direccion,
                localidad: coma === -1 ? zona : zona.slice(0, coma).trim(),
                provincia: coma === -1 ? "" : zona.slice(coma + 1).trim()
            };
        })
        .filter(l => l.direccion || l.localidad);

// Texto de lo que muestra la lista (para saber si cambió).
const firmaDeLocales = () => {
    const lista = document.querySelector('ul[aria-label="Comercios adheridos"]');
    const paginacion = document.querySelector('[aria-label="Paginación de comercios adheridos"]');

    return (lista ? lista.innerText : "") + "||" + (paginacion ? paginacion.innerText : "");
};

// ---- Selectores desplegables (react-select, prefijo de clases "Select__") ----

const leerEstadoSelector = etiqueta => {
    const input = document.querySelector('input[aria-label="' + etiqueta + '"]');
    if (!input) return { existe: false, deshabilitado: false, valor: "" };

    const control = input.closest('[class*="Select__control"]');
    const elegido = control ? control.querySelector('[class*="Select__single-value"]') : null;

    return {
        existe: true,
        deshabilitado:
            !!input.disabled ||
            (!!control && control.getAttribute("aria-disabled") === "true") ||
            !!input.closest('[aria-disabled="true"]'),
        valor: elegido ? (elegido.textContent || "").trim() : ""
    };
};

const obtenerControl = etiqueta => {
    const input = document.querySelector('input[aria-label="' + etiqueta + '"]');
    return input ? input.closest('[class*="Select__control"]') : null;
};

// Opciones de la lista desplegada (solo existe mientras está abierta).
const leerOpcionesAbiertas = () =>
    Array.from(document.querySelectorAll('[class*="Select__option"]'))
        .map(el => (el.textContent || "").trim());

const obtenerOpcion = indice =>
    Array.from(document.querySelectorAll('[class*="Select__option"]'))[indice] || null;


// ------------------------------------------------------------
// LISTADO DE PROMOCIONES
// ------------------------------------------------------------

const leerTarjetasListado = page => page.evaluate(leerTarjetas, SEL_TARJETA);

// Abre la página N del listado. Devuelve las tarjetas ([] si no hay ninguna).
async function cargarListado(page, numero) {
    await irA(page, urlListado(numero));

    try {
        await page.waitForSelector(SEL_TARJETA, { timeout: 20000 });
    } catch (_) {
        return [];
    }

    await esperarEstable(async () =>
        (await leerTarjetasListado(page)).map(t => t.clave).join("||")
    );

    return leerTarjetasListado(page);
}

// Abre la promoción de la tarjeta indicada (recarga el listado: es lo más seguro).
async function abrirPromocion(page, numeroPagina, tarjeta) {
    const tarjetas = await cargarListado(page, numeroPagina);
    const indice = tarjetas.findIndex(t => t.clave === tarjeta.clave);

    if (indice === -1) {
        throw new Error(`No encontré la tarjeta "${tarjeta.nombre}" en la página ${numeroPagina} del listado`);
    }

    for (let intento = 1; intento <= 2; intento++) {
        const elemento = (await page.evaluateHandle(obtenerTarjeta, SEL_TARJETA, indice)).asElement();

        if (!elemento) throw new Error("No pude tomar la tarjeta del listado");

        await elemento.click();

        try {
            await page.waitForFunction(
                () => location.pathname.startsWith("/promocion/"),
                { timeout: intento === 1 ? 8000 : 15000 }
            );
            break;
        } catch (_) {
            // Si la página todavía no estaba lista para recibir el click, lo repetimos.
            if (intento === 2) throw new Error("No se abrió la promoción al clickear la tarjeta");
        }
    }

    await page.waitForSelector(SEL_ARTICULO, { timeout: 20000 });
}


// ------------------------------------------------------------
// SUCURSALES (pantalla "Comercios adheridos")
// ------------------------------------------------------------

// Espera a que la lista de locales esté completa y estable.
async function esperarListaDeLocales(page, timeout = 15000) {
    const limite = Date.now() + timeout;
    let anterior = "";
    let info = null;

    while (Date.now() < limite) {
        info = await page.evaluate(leerPaginacionLocales).catch(() => null);

        if (info) {
            const esperados = info.total === 0 ? 0 : info.hasta - info.desde + 1;
            const completa = info.visibles === esperados;
            const clave = completa ? JSON.stringify(info) : "";

            if (completa && clave === anterior) return info;
            anterior = clave;
        }

        await dormir(300);
    }

    return info;
}

// Espera a que la lista cambie respecto de una firma anterior (o que pase el tiempo).
async function esperarCambioDeLista(page, antes, timeout = 6000) {
    const limite = Date.now() + timeout;

    while (Date.now() < limite) {
        const actual = await page.evaluate(firmaDeLocales).catch(() => antes);
        if (actual !== antes) return true;
        await dormir(250);
    }

    return false;
}

// Busca en las opciones la que pidió el usuario. Ignora tildes y mayúsculas.
//   exacta            -> { indice }
//   una sola parcial  -> { indice, aproximada: true }   (ej.: "Lanus" -> "Lanus Oeste")
//   varias parciales  -> { indice: -1, ambigua: [nombres] }
//   ninguna           -> { indice: -1 }
function buscarCoincidencia(opciones, valor) {
    const objetivo = normalizar(valor);

    const exacta = opciones.findIndex(o => normalizar(o.nombre) === objetivo);
    if (exacta !== -1) return { indice: exacta };

    const parciales = opciones
        .map((o, indice) => ({ o, indice }))
        .filter(({ o }) => normalizar(o.nombre).includes(objetivo));

    if (parciales.length === 1) return { indice: parciales[0].indice, aproximada: true };
    if (parciales.length > 1) return { indice: -1, ambigua: parciales.map(({ o }) => o.nombre) };

    return { indice: -1 };
}

const resumirOpciones = (opciones, max = 20) =>
    opciones.slice(0, max).join(", ") +
    (opciones.length > max ? `, ... (${opciones.length} en total)` : "");

// Espera a que la lista desplegada tenga opciones y deje de cambiar.
async function esperarOpciones(page, timeout = 8000) {
    const limite = Date.now() + timeout;
    let opciones = [];
    let ultima = -1;
    let estables = 0;

    while (Date.now() < limite) {
        opciones = await page.evaluate(leerOpcionesAbiertas).catch(() => []);

        if (opciones.length > 0) {
            estables = opciones.length === ultima ? estables + 1 : 0;
            ultima = opciones.length;
            if (estables >= 2) return opciones;
        }

        await dormir(250);
    }

    return opciones;
}

async function cerrarMenu(page) {
    await page.keyboard.press("Escape").catch(() => {});
    await dormir(200);
}

// Abre el selector (Provincia / Localidad) y elige la opción que coincide con `valor`.
// Devuelve { ok: true } o { ok: false, noExiste, motivo, opciones }:
//   noExiste = true  -> se vio la lista y esa opción no está
//   noExiste = false -> problema técnico, o varias opciones coinciden
async function elegirEnSelector(page, etiqueta, valor) {
    let estado = await page.evaluate(leerEstadoSelector, etiqueta);

    if (!estado.existe) {
        await guardarDiagnostico(page, `sin_selector_${etiqueta}`);
        return { ok: false, noExiste: false, motivo: `No encontré el selector de ${etiqueta}` };
    }

    // La localidad se habilita al elegir la provincia (puede tardar un instante).
    const limite = Date.now() + 6000;

    while (estado.deshabilitado && Date.now() < limite) {
        await dormir(300);
        estado = await page.evaluate(leerEstadoSelector, etiqueta);
    }

    if (estado.deshabilitado) {
        // Con una sola opción, el sitio puede dejarlo deshabilitado y ya elegido.
        if (estado.valor) {
            logZona(`${etiqueta}: deshabilitado, con "${estado.valor}" ya elegida`);

            return normalizar(estado.valor) === normalizar(valor)
                ? { ok: true, yaEstaba: true }
                : { ok: false, noExiste: true, opciones: [estado.valor] };
        }

        await guardarDiagnostico(page, `deshabilitado_${etiqueta}`);
        return { ok: false, noExiste: false, motivo: `El selector de ${etiqueta} está deshabilitado` };
    }

    // La página puede recordar la elección anterior: si ya está, no hace falta abrirlo.
    if (estado.valor && normalizar(estado.valor) === normalizar(valor)) {
        logZona(`${etiqueta}: ya estaba elegida "${estado.valor}"`);
        return { ok: true, yaEstaba: true };
    }

    let ultimoMotivo = `No pude elegir "${valor}" en ${etiqueta}`;

    for (let intento = 1; intento <= 2; intento++) {
        // La lista solo existe mientras está abierta: si ya lo está, no la tocamos
        // (un click más la cerraría).
        const yaAbierta = (await page.evaluate(leerOpcionesAbiertas)).length > 0;

        if (!yaAbierta) {
            logZona(`${etiqueta}: abriendo el selector (intento ${intento})`);

            const control = (await page.evaluateHandle(obtenerControl, etiqueta)).asElement();
            if (!control) break;

            await control.click();
        }

        const nombres = await esperarOpciones(page);

        logZona(
            `${etiqueta}: ${nombres.length} opciones` +
            (nombres.length ? ` (${resumirOpciones(nombres, 10)})` : "")
        );

        if (nombres.length === 0) {
            ultimoMotivo = `No pude ver las opciones del selector de ${etiqueta}`;
            await guardarDiagnostico(page, `sin_opciones_${etiqueta}`);
            continue;
        }

        const coincidencia = buscarCoincidencia(nombres.map(n => ({ nombre: n })), valor);

        if (coincidencia.ambigua) {
            await cerrarMenu(page);

            return {
                ok: false,
                noExiste: false,
                motivo:
                    `"${valor}" coincide con varias opciones de ${etiqueta} ` +
                    `(${coincidencia.ambigua.join(", ")}). Escribila completa.`
            };
        }

        if (coincidencia.indice === -1) {
            logZona(`${etiqueta}: "${valor}" no figura entre las opciones`);
            await cerrarMenu(page);

            return { ok: false, noExiste: true, opciones: nombres };
        }

        const elegida = nombres[coincidencia.indice];

        if (coincidencia.aproximada) {
            logZona(`${etiqueta}: "${valor}" no es exacto; uso "${elegida}"`);
        }

        const opcion = (await page.evaluateHandle(obtenerOpcion, coincidencia.indice)).asElement();

        if (!opcion) {
            ultimoMotivo = `No pude tomar la opción "${elegida}" de ${etiqueta}`;
            continue;
        }

        await opcion.click(); // se desplaza hasta la opción si hace falta
        await dormir(700);

        // Comprobamos que la opción quedó elegida (para no seguir sin filtro).
        estado = await page.evaluate(leerEstadoSelector, etiqueta);

        if (normalizar(estado.valor) === normalizar(elegida)) {
            logZona(`${etiqueta}: elegida "${elegida}"`);
            return { ok: true };
        }

        ultimoMotivo = `Hice click en "${elegida}" (${etiqueta}) pero el selector muestra "${estado.valor}"`;
        await guardarDiagnostico(page, `no_quedo_${etiqueta}`);
    }

    return { ok: false, noExiste: false, motivo: ultimoMotivo };
}

// Aplica ZONA (provincia y, si hay, localidad) en la pantalla de comercios adheridos.
// Devuelve { estado: "ok" | "sin_locales" | "no_aplicable", mensaje }.
async function aplicarZona(page) {
    const antes = await page.evaluate(firmaDeLocales);

    const provincia = await elegirEnSelector(page, "Provincia", ZONA.provincia);

    if (!provincia.ok) {
        return provincia.noExiste
            ? {
                estado: "sin_locales",
                mensaje: `No hay sucursales en ${descripcionZona()} para esta promoción ` +
                         `(la provincia "${ZONA.provincia}" no figura entre las disponibles)`,
                opciones: provincia.opciones
            }
            : { estado: "no_aplicable", mensaje: provincia.motivo };
    }

    // Al elegir la provincia se habilita la localidad y la lista se filtra.
    if (!provincia.yaEstaba) await esperarCambioDeLista(page, antes);

    if (ZONA.localidad) {
        const antesLocalidad = await page.evaluate(firmaDeLocales);
        const localidad = await elegirEnSelector(page, "Localidad", ZONA.localidad);

        if (!localidad.ok) {
            return localidad.noExiste
                ? {
                    estado: "sin_locales",
                    mensaje: `No hay sucursales en ${descripcionZona()} para esta promoción ` +
                             `(la localidad "${ZONA.localidad}" no figura entre las disponibles)`,
                    opciones: localidad.opciones
                }
                : { estado: "no_aplicable", mensaje: localidad.motivo };
        }

        if (!localidad.yaEstaba) await esperarCambioDeLista(page, antesLocalidad);
    }

    const info = await esperarListaDeLocales(page);

    const vacia = !info || info.total === 0 || (info.total === null && info.visibles === 0);

    return vacia
        ? { estado: "sin_locales", mensaje: `No hay sucursales en ${descripcionZona()} para esta promoción` }
        : { estado: "ok" };
}

// Lee todas las páginas de la lista de locales que se está viendo.
async function leerPaginasDeLocales(page) {
    const locales = [];
    let total = null;
    let completo = true;

    // Si la lista quedó en una página distinta de la 1, volvemos.
    for (let i = 0; i < 200; i++) {
        const info = await page.evaluate(leerPaginacionLocales);

        if (!info || !info.hayAnterior) break;

        const antes = await page.evaluate(firmaDeLocales);
        const boton = await page.$('[aria-label="Paginación de comercios adheridos"] button[aria-label="Página anterior"]');
        if (!boton) break;

        await boton.click();
        await esperarCambioDeLista(page, antes, 8000);
    }

    for (let pagina = 1; ; pagina++) {
        const info = await esperarListaDeLocales(page);

        locales.push(...(await page.evaluate(leerLocalesDeLista)));

        if (info && info.total !== null) total = info.total;

        if (!info || !info.hayMas) break;

        if (pagina >= MAX_PAGINAS_SUCURSALES) {
            completo = false;
            break;
        }

        const antes = await page.evaluate(firmaDeLocales);
        const siguiente = await page.$('[aria-label="Paginación de comercios adheridos"] button[aria-label="Página siguiente"]');

        if (!siguiente) break;

        await siguiente.click();

        if (!(await esperarCambioDeLista(page, antes, 8000))) {
            completo = false; // la pantalla no avanzó: conservamos lo leído
            break;
        }
    }

    if (total !== null && locales.length !== total) completo = false;

    return { locales, total, completo };
}

// Entra a la pantalla de comercios adheridos de una promoción, aplica el filtro de zona
// (si lo hay) y lee los locales.
async function leerSucursales(page, href) {
    await irA(page, href);
    await page.waitForSelector('[aria-label="Filtros de ubicación"]', { timeout: 20000 });
    await esperarListaDeLocales(page);

    const url = page.url();
    let zona = null;

    if (ZONA.provincia) {
        const resultado = await aplicarZona(page);

        if (resultado.estado === "no_aplicable") {
            // No leemos "todo" por las dudas: el usuario pidió una zona.
            throw new Error(
                `No pude aplicar el filtro de zona (${descripcionZona()}): ${resultado.mensaje}`
            );
        }

        zona = {
            provincia: ZONA.provincia,
            localidad: ZONA.localidad,
            estado: resultado.estado
        };

        if (resultado.estado === "sin_locales") {
            zona.mensaje = resultado.mensaje;
            if (resultado.opciones) zona.opciones_vistas = resultado.opciones;

            console.log(`   ${resultado.mensaje}`);

            if (resultado.opciones && resultado.opciones.length) {
                console.log(`   Disponibles: ${resumirOpciones(resultado.opciones)}`);
            }

            return { total: 0, locales: [], completo: true, url, zona };
        }
    }

    const lectura = await leerPaginasDeLocales(page);

    return { ...lectura, url, zona };
}


// ------------------------------------------------------------
// SALIDA: JSON ordenado y prolijo
// ------------------------------------------------------------
// Lo leído se guarda en memoria con todo el detalle (resultado). Antes de
// escribir se convierte a un formato limpio y se reparte en dos archivos:
//
//   data/promociones_terminos_y_condiciones.json
//       supermercados -> promociones (beneficio, días, vigencia, tope, pago, ...
//       y los términos y condiciones completos de cada promoción)
//
//   data/sucursales.json
//       supermercados -> promociones -> locales adheridos (y la zona consultada)
//
// Con una zona elegida (provincia / localidad), solo se guardan los supermercados
// y promociones que tienen al menos un local en esa zona.
// ------------------------------------------------------------

// true -> "si", false/null/undefined -> "no"
const siNo = valor => (valor ? "si" : "no");

// "1.234,50" -> 1234.5
const aNumero = texto => {
    if (!texto) return null;

    const n = Number(String(texto).replace(/\./g, "").replace(",", "."));
    return Number.isFinite(n) ? n : null;
};

// "08/09/2026" -> "2026-09-08"
const fechaISO = texto => {
    const m = (texto || "").match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    return m ? `${m[3]}-${m[2]}-${m[1]}` : null;
};

// "20% de ahorro." -> "20% de ahorro"
const sinPuntoFinal = texto => (texto || "").replace(/[.\s]+$/, "").trim();

const compactar = objeto =>
    Object.fromEntries(
        Object.entries(objeto).filter(([, valor]) => valor !== null && valor !== undefined)
    );

// "20% de ahorro"                -> { tipo: "ahorro", porcentaje: 20 }
// "Hasta 12 cuotas sin interés"  -> { tipo: "cuotas_sin_interes", cuotas: 12, hasta: "si" }
function clasificarBeneficio(texto) {
    const t = texto || "";
    const cuotas = t.match(/(\d+)\s*cuotas/i);
    const porcentaje = t.match(/(\d+(?:[.,]\d+)?)\s*%/);

    if (cuotas) {
        return {
            tipo: /sin\s+inter[eé]s/i.test(t) ? "cuotas_sin_interes" : "cuotas",
            cuotas: parseInt(cuotas[1], 10),
            hasta: siNo(/^hasta\b/i.test(t))
        };
    }

    if (porcentaje) {
        return {
            tipo: /ahorro|reintegro|descuento/i.test(t) ? "ahorro" : "porcentaje",
            porcentaje: aNumero(porcentaje[1])
        };
    }

    return { tipo: "otro" };
}

// "Tope de reintegro: $15.000 por cliente por mes. Incluye compras con tarjetas adicionales."
// ("Sin tope de reintegro." no coincide: la promoción no tiene tope.)
function extraerTope(texto) {
    const t = texto || "";
    const m = t.match(/tope\s+de\s+reintegro:?\s*\$\s*([\d.]+(?:,\d+)?)/i);

    if (!m) return null;

    const periodo = (t.match(/\bpor\s+(mes|semana|d[ií]a|compra)\b/i) || [])[1];

    return {
        monto: aNumero(m[1]),
        moneda: "ARS",
        periodo: periodo ? periodo.toLowerCase().replace("dia", "día") : null,
        por_cliente: siNo(/por\s+cliente/i.test(t)),
        incluye_tarjetas_adicionales: siNo(/tarjetas\s+adicionales/i.test(t))
    };
}

// "...en compras superiores a $ 75.000 realizadas..." -> 75000
function extraerCompraMinima(texto) {
    const m = (texto || "").match(/compras?\s+(?:superiores?|mayores?)\s+a\s+\$\s*([\d.]+(?:,\d+)?)/i);
    return m ? aNumero(m[1]) : null;
}

// [{ tipo: "Crédito", tarjetas: [{ nombre, imagen }] }] -> { debito: [urls], credito: [urls], otros: [urls] }
function ordenarMediosDePago(medios) {
    const resultado = { debito: [], credito: [], otros: [] };

    for (const grupo of medios || []) {
        const tipo = normalizar(grupo.tipo);
        const clave = tipo === "debito" ? "debito" : tipo === "credito" ? "credito" : "otros";

        for (const tarjeta of grupo.tarjetas || []) {
            // Se guarda la URL de la imagen: el texto alternativo del sitio a veces es
            // solo el nombre del archivo ("Visa_Black.png", "TarjetaVisa.png").
            const imagen = typeof tarjeta === "string"
                ? tarjeta
                : tarjeta.imagen || tarjeta.nombre || "";

            if (imagen && !resultado[clave].includes(imagen)) resultado[clave].push(imagen);
        }
    }

    return resultado;
}

function limpiarSucursales(promo) {
    const d = promo.detalle;

    if (!d || !d.tiene_conocer_mas) return null; // la promoción no tiene sección de locales

    const unicas = new Map();

    for (const s of promo.sucursales || []) {
        const direccion = (s.direccion || "").replace(/\s+/g, " ").trim();
        const localidad = (s.localidad || "").replace(/\s+/g, " ").trim();
        const provincia = (s.provincia || "").replace(/\s+/g, " ").trim();

        unicas.set(
            `${normalizar(direccion)}|${normalizar(localidad)}|${normalizar(provincia)}`,
            { direccion, localidad, provincia }
        );
    }

    const lista = Array.from(unicas.values()).sort(
        (a, b) =>
            a.provincia.localeCompare(b.provincia, "es") ||
            a.localidad.localeCompare(b.localidad, "es") ||
            a.direccion.localeCompare(b.direccion, "es")
    );

    const z = d.sucursales_zona || null;

    return {
        cantidad: lista.length,
        total_informado: d.sucursales_total !== undefined ? d.sucursales_total : null,
        completas: siNo(d.sucursales_completas),
        zona: z
            ? compactar({
                provincia: z.provincia || null,
                localidad: z.localidad || null,
                resultado: z.estado === "sin_locales" ? "sin_sucursales_en_la_zona" : "ok",
                mensaje: z.mensaje || null,
                opciones_disponibles: z.opciones_vistas || null
            })
            : null,
        url: d.url_locales || null,
        lista
    };
}

function limpiarPromocion(promo) {
    const d = promo.detalle || null;
    const errores = [];

    if (promo.error) errores.push({ etapa: "promocion", mensaje: promo.error });
    if (promo.detalle_error) errores.push({ etapa: "detalle", mensaje: promo.detalle_error });
    if (d && d.sucursales_error) errores.push({ etapa: "sucursales", mensaje: d.sucursales_error });

    // Promoción que no se pudo leer (sin detalle): solo el error.
    if (!d) {
        return compactar({
            id: null,
            texto_tarjeta: promo.texto ? promo.texto.replace(/\s+/g, " ") : null,
            errores
        });
    }

    const textoBeneficio = sinPuntoFinal(d.beneficio || "");

    const salida = {
        id: d.id_promocion || null,
        url: d.url || null,
        beneficio: { texto: textoBeneficio, ...clasificarBeneficio(textoBeneficio) },
        dias: d.dias || [],
        donde_comprar: compactar({
            modalidad: d.modalidad || null,
            tienda_online: d.tienda_online || null
        }),
        vigencia: d.vigencia
            ? { desde: fechaISO(d.vigencia.desde), hasta: fechaISO(d.vigencia.hasta) }
            : null,
        // "no" = la promoción no tiene tope / compra mínima
        tope_reintegro: extraerTope(d.condiciones_resumen) || "no",
        compra_minima: extraerCompraMinima(d.terminos_y_condiciones) || "no",
        pago: {
            con_qr: siNo(d.paga_con_qr),
            como_pagar: sinPuntoFinal(d.como_pagar),
            ...ordenarMediosDePago(d.medios_de_pago)
        },
        cftea: d.cftea && Object.keys(d.cftea).length ? d.cftea : null,
        terminos_y_condiciones: d.terminos_y_condiciones || null,
        sucursales: limpiarSucursales(promo)
    };

    if (errores.length) salida.errores = errores;

    return salida;
}

// Convierte lo leído al formato final.
function crearSalida(resultado) {
    const supermercados = resultado
        .map(grupo => {
            const promociones = (grupo.promociones || []).map(p => limpiarPromocion(p));

            const conCategoria = (grupo.promociones || [])
                .map(p => (p.detalle && p.detalle.categoria) || p.categoria)
                .find(Boolean);

            return {
                nombre: limpiarNombre(grupo.supermercado || ""),
                logo: grupo.imagen || null,
                categoria: conCategoria || "Supermercados",
                promociones
            };
        })
        .sort((a, b) => a.nombre.localeCompare(b.nombre, "es"));

    return {
        version: 3,
        generado: new Date().toISOString(),
        fuente: urlListado(1),
        zona_sucursales: ZONA.provincia
            ? { provincia: ZONA.provincia, localidad: ZONA.localidad || null }
            : null, // null = sin filtro: todas las sucursales
        supermercados
    };
}

// Errores de una promoción: los de la etapa "sucursales" van al archivo de sucursales;
// el resto, al de promociones.
const erroresDe = (errores, deSucursales) =>
    (errores || []).filter(e => (e.etapa === "sucursales") === deSucursales);

// Reparte la salida completa en los dos archivos.
function separarSalida(salida) {
    const cabecera = { version: salida.version, generado: salida.generado, fuente: salida.fuente };
    const hayZona = !!salida.zona_sucursales;
    const filtrar = hayZona && SOLO_SUPERMERCADOS_EN_LA_ZONA;

    // ¿La promoción tiene al menos un local en la zona elegida? "si" | "no" | "sin datos"
    const estadoEnLaZona = p => {
        if (!p.sucursales) return "sin datos"; // sin sección de locales (online)
        if (p.sucursales.zona && p.sucursales.zona.resultado === "sin_sucursales_en_la_zona") return "no";
        if (p.sucursales.cantidad > 0) return "si";

        return erroresDe(p.errores, true).length ? "sin datos" : "no";
    };

    // ---- Promociones y términos y condiciones ----
    let supermercadosPromociones = salida.supermercados.map(s => {
        const promos = s.promociones.map(p => {
            const { sucursales, errores, ...resto } = p;
            const propios = erroresDe(errores, false);
            const base = propios.length ? { ...resto, errores: propios } : resto;

            if (!hayZona) return base;

            // Las marcas de la zona van justo después del id y la url.
            const { id, url, ...demas } = base;

            return {
                ...(id !== undefined ? { id, url } : {}),
                tiene_sucursal_en_la_zona: estadoEnLaZona(p),
                sucursales_en_la_zona: p.sucursales ? p.sucursales.cantidad : 0,
                ...demas
            };
        });

        if (!hayZona) {
            return { nombre: s.nombre, logo: s.logo, categoria: s.categoria, promociones: promos };
        }

        const estados = s.promociones.map(estadoEnLaZona);
        const unicas = new Set();

        for (const p of s.promociones) {
            for (const l of (p.sucursales && p.sucursales.lista) || []) {
                unicas.add(`${normalizar(l.direccion)}|${normalizar(l.localidad)}|${normalizar(l.provincia)}`);
            }
        }

        return {
            nombre: s.nombre,
            logo: s.logo,
            categoria: s.categoria,
            tiene_sucursal_en_la_zona: estados.includes("si")
                ? "si"
                : estados.every(e => e === "no") ? "no" : "sin datos",
            sucursales_en_la_zona: unicas.size,
            promociones: promos
        };
    });

    const totales = lista => ({
        supermercados: lista.length,
        promociones: lista.reduce((n, s) => n + s.promociones.length, 0)
    });

    const antes = totales(supermercadosPromociones);

    // Solo los supermercados y promociones con al menos un local en la zona elegida.
    if (filtrar) {
        supermercadosPromociones = supermercadosPromociones
            .filter(s => s.tiene_sucursal_en_la_zona === "si")
            .map(({ tiene_sucursal_en_la_zona, promociones, ...s }) => ({
                ...s,
                promociones: promociones
                    .filter(p => p.tiene_sucursal_en_la_zona === "si")
                    .map(({ tiene_sucursal_en_la_zona: _marca, ...p }) => p)
            }));
    }

    const despues = totales(supermercadosPromociones);

    const resumenPromociones = {
        ...despues,
        promociones_con_errores: supermercadosPromociones.reduce(
            (n, s) => n + s.promociones.filter(p => p.errores).length, 0
        )
    };

    if (filtrar) {
        resumenPromociones.no_guardados_por_no_tener_sucursal_en_la_zona = {
            supermercados: antes.supermercados - despues.supermercados,
            promociones: antes.promociones - despues.promociones
        };
    }

    const promociones = {
        ...cabecera,
        zona_sucursales: salida.zona_sucursales || "no", // "no" = sin filtro de zona
        resumen: resumenPromociones,
        supermercados: supermercadosPromociones
    };

    // ---- Sucursales ----
    // Solo promociones que se pudieron abrir (tienen id); con zona elegida y el
    // filtro activo, solo las que tienen al menos un local en esa zona.
    const supermercadosSucursales = salida.supermercados
        .map(s => ({
            nombre: s.nombre,
            logo: s.logo,
            promociones: s.promociones
                .filter(p => p.id && (!filtrar || estadoEnLaZona(p) === "si"))
                .map(p => {
                    const entrada = {
                        id: p.id,
                        url: p.url,
                        beneficio: p.beneficio ? p.beneficio.texto : null,
                        dias: p.dias || [],
                        vigencia: p.vigencia || null,
                        sucursales: p.sucursales || null
                    };

                    const propios = erroresDe(p.errores, true);
                    if (propios.length) entrada.errores = propios;

                    return entrada;
                })
        }))
        .filter(s => s.promociones.length > 0);

    const promosSucursales = supermercadosSucursales.flatMap(s => s.promociones);

    const resumenSucursales = {
        supermercados: supermercadosSucursales.length,
        promociones: promosSucursales.length,
        promociones_con_sucursales: promosSucursales.filter(
            p => p.sucursales && p.sucursales.cantidad > 0
        ).length,
        promociones_sin_sucursales_en_la_zona: promosSucursales.filter(
            p => p.sucursales && p.sucursales.zona && p.sucursales.zona.resultado === "sin_sucursales_en_la_zona"
        ).length,
        sucursales_leidas: promosSucursales.reduce(
            (n, p) => n + (p.sucursales ? p.sucursales.cantidad : 0), 0
        ),
        promociones_con_errores: promosSucursales.filter(p => p.errores).length
    };

    // "no" = la promoción no tiene sección de locales (recién ahora, para no alterar los conteos)
    for (const p of promosSucursales) {
        if (p.sucursales === null) p.sucursales = "no";
    }

    const sucursales = {
        ...cabecera,
        zona_sucursales: salida.zona_sucursales || "no", // "no" = sin filtro de zona
        resumen: resumenSucursales,
        supermercados: supermercadosSucursales
    };

    return { promociones, sucursales };
}

function guardarSalida(resultado) {
    const salida = crearSalida(resultado);
    const { promociones, sucursales } = separarSalida(salida);

    fs.writeFileSync(ARCHIVO_PROMOCIONES, JSON.stringify(promociones, null, 2), "utf8");
    fs.writeFileSync(ARCHIVO_SUCURSALES, JSON.stringify(sucursales, null, 2), "utf8");

    if (GUARDAR_CRUDO) {
        fs.writeFileSync(ARCHIVO_CRUDO, JSON.stringify(resultado, null, 2), "utf8");
    }
}


// ------------------------------------------------------------
// ZONA DE SUCURSALES: pregunta inicial
// ------------------------------------------------------------
// Se puede pasar por línea de comandos para no tener que contestar:
//   node index.js "--provincia=Buenos Aires" "--localidad=La Plata"
// (las comillas van alrededor de todo el argumento, así funciona en PowerShell y cmd)
// ------------------------------------------------------------

const argumentoDeLinea = nombre => {
    const prefijo = `--${nombre}=`;
    const arg = process.argv.find(a => a.startsWith(prefijo));

    return arg ? arg.slice(prefijo.length).replace(/^["']|["']$/g, "").trim() : null;
};

async function definirZona() {
    const provinciaArg = argumentoDeLinea("provincia");

    if (provinciaArg !== null) {
        return { provincia: provinciaArg, localidad: argumentoDeLinea("localidad") || "" };
    }

    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const preguntar = texto => new Promise(resolve => rl.question(texto, resolve));

    console.log("\n=== Zona de sucursales ===");
    console.log("De cada promoción se leerán solo las sucursales de la zona que elijas.");
    console.log("Si dejás la provincia vacía se leen TODAS las sucursales (puede tardar mucho).\n");

    const provincia = (await preguntar("Provincia: ")).trim();
    let localidad = "";

    if (provincia) {
        localidad = (await preguntar("Localidad (Enter = toda la provincia): ")).trim();
    }

    rl.close();

    return { provincia, localidad };
}

function mostrarResumenDeZona(resultado) {
    if (!ZONA.provincia) return;

    let con = 0;
    let sin = 0;
    let fallo = 0;

    for (const supermercado of resultado) {
        for (const promo of supermercado.promociones || []) {
            const d = promo.detalle;

            if (!d || !d.tiene_conocer_mas) continue;

            if (d.sucursales_error) fallo++;
            else if (d.sucursales_zona && d.sucursales_zona.estado === "sin_locales") sin++;
            else if ((promo.sucursales || []).length > 0) con++;
        }
    }

    console.log(`\nZona: ${descripcionZona()}`);
    console.log(`Promociones con sucursales en la zona: ${con}`);
    console.log(`Promociones SIN sucursales en la zona: ${sin}`);

    if (fallo > 0) {
        console.log(`No se pudo aplicar el filtro en ${fallo} promoción(es): ver sucursales_error en el JSON.`);
        console.log("Si pasa en todas, revisá data/diagnostico_*.png y data/diagnostico_*.html.");
    }
}


// ------------------------------------------------------------
// PRINCIPAL
// ------------------------------------------------------------

// Lee la promoción que está abierta (y sus sucursales). Devuelve el objeto de la promoción.
async function leerPromocionAbierta(page, tarjeta) {
    const crudo = await page.evaluate(extraerPromocion);

    if (!crudo) throw new Error("No encontré el detalle de la promoción en la pantalla");

    const detalle = {
        ...crudo,
        tiene_conocer_mas: !!crudo.comercios_href
    };

    let sucursales = [];

    if (LEER_SUCURSALES && crudo.comercios_href) {
        try {
            const lectura = await leerSucursales(page, crudo.comercios_href);

            detalle.sucursales_total = lectura.total;
            detalle.sucursales_completas = lectura.completo;
            detalle.url_locales = lectura.url;
            detalle.sucursales_zona = lectura.zona;
            sucursales = lectura.locales;
        } catch (error) {
            if (esErrorFatal(error)) throw error;

            detalle.sucursales_error = error.message;
            console.log(`   sucursales: ${error.message}`);
        }
    }

    return {
        indice: tarjeta.indice,
        marca: crudo.marca,
        categoria: crudo.categoria,
        beneficio: crudo.beneficio,
        dias: crudo.dias,
        texto: tarjeta.texto,
        detalle,
        sucursales
    };
}

async function main() {
    fs.mkdirSync(CARPETA_DATA, { recursive: true });

    // Zona de sucursales (solo si se leen sucursales)
    if (LEER_SUCURSALES) {
        ZONA = await definirZona();

        console.log(
            ZONA.provincia
                ? `\nSe leerán las sucursales de: ${descripcionZona()}`
                : "\nSe leerán TODAS las sucursales."
        );
    }

    const browser = await puppeteer.launch({
        headless: false,
        defaultViewport: { width: 1366, height: 900 }
    });

    const page = await browser.newPage();

    // Sin permisos concedidos, Chrome rechaza la ubicación sin mostrar el cartel de permiso.
    try {
        await browser.defaultBrowserContext().overridePermissions(ORIGEN, []);
    } catch (_) {
        // no es imprescindible
    }

    const resultado = [];
    const guardar = () => guardarSalida(resultado);

    // Ctrl+C: guarda lo leído, cierra el navegador y sale.
    process.once("SIGINT", async () => {
        console.log("\nInterrumpido: guardando lo leído y cerrando el navegador...");

        try { guardar(); } catch (_) { /* nada */ }
        await browser.close().catch(() => {});

        process.exit(130);
    });

    try {
        // ----------------------------------------------------
        // FASE 1: recorrer el listado (página por página)
        // ----------------------------------------------------
        const paginas = [];
        const paginasVistas = new Set();

        for (let numero = 1; numero <= MAX_PAGINAS_LISTADO; numero++) {
            const tarjetas = await cargarListado(page, numero);

            if (tarjetas.length === 0) {
                if (numero === 1) {
                    await guardarDiagnostico(page, "listado_vacio");
                    throw new Error(
                        "No encontré promociones en el listado. Revisá data/diagnostico_listado_vacio.html " +
                        "(puede que la página haya cambiado)."
                    );
                }

                break; // pasamos la última página
            }

            // Protección: si una página ya se vio (el listado "da la vuelta"), terminamos.
            const huella = tarjetas.map(t => t.clave).join("||");

            if (paginasVistas.has(huella)) {
                console.log("La página se repite: se terminó el listado.");
                break;
            }

            paginasVistas.add(huella);
            paginas.push({ numero, tarjetas });

            console.log(`Página ${numero}: ${tarjetas.length} promociones`);
        }

        const total = paginas.reduce((n, p) => n + p.tarjetas.length, 0);
        console.log(`\nTotal en el listado: ${total} promociones en ${paginas.length} páginas`);

        // ----------------------------------------------------
        // FASE 2: entrar a cada promoción
        // ----------------------------------------------------
        const porMarca = new Map();
        let hechas = 0;

        for (const pagina of paginas) {
            console.log(`\n=== Página ${pagina.numero} ===`);

            for (const tarjeta of pagina.tarjetas) {
                console.log(`-> [${++hechas}/${total}] ${tarjeta.nombre}`);

                let promo = { indice: tarjeta.indice, texto: tarjeta.texto };

                try {
                    await abrirPromocion(page, pagina.numero, tarjeta);
                    promo = await leerPromocionAbierta(page, tarjeta);

                    const d = promo.detalle;
                    const esperadas = d.sucursales_total != null ? `/${d.sucursales_total}` : "";

                    console.log(
                        `   ${d.beneficio} | ${d.modalidad || "sin modalidad"}` +
                        (d.tiene_conocer_mas ? ` | sucursales: ${promo.sucursales.length}${esperadas}` : "")
                    );
                } catch (error) {
                    if (esErrorFatal(error)) {
                        throw new Error(
                            `Se cerró el navegador o se perdió la conexión (${error.message}). ` +
                            `Lo ya leído quedó guardado en el JSON.`
                        );
                    }

                    promo.error = error.message;
                    console.log(`   ERROR: ${error.message}`);

                    await page.screenshot({
                        path: path.join(CARPETA_DATA, `error_${pagina.numero}_${tarjeta.indice}.png`)
                    }).catch(() => {});
                }

                const marca = limpiarNombre(promo.marca || tarjeta.nombre);
                let grupo = porMarca.get(marca);

                if (!grupo) {
                    grupo = {
                        supermercado: marca,
                        imagen: (promo.detalle && promo.detalle.logo) || tarjeta.imagen,
                        pagina: pagina.numero,
                        promociones: []
                    };

                    porMarca.set(marca, grupo);
                    resultado.push(grupo);
                }

                grupo.promociones.push(promo);
                guardar(); // guardamos después de cada promoción

                await pausaCorta();
            }
        }

        console.log(`\nListo. Supermercados: ${resultado.length}`);
        console.log(`Promociones y términos: ${ARCHIVO_PROMOCIONES}`);
        console.log(`Sucursales: ${ARCHIVO_SUCURSALES}`);
        mostrarResumenDeZona(resultado);

    } catch (error) {
        console.error("ERROR DEL SCRAPER:", error);
        guardar();
    } finally {
        if (CERRAR_AL_TERMINAR) {
            console.log("\nCerrando el navegador...");
            await browser.close().catch(() => {});
        }
    }
}

// Se exporta para poder probar las funciones sin abrir el navegador.
if (require.main === module) {
    main()
        .catch(error => {
            console.error("ERROR FATAL:", error);
            process.exitCode = 1;
        })
        .finally(() => {
            // Termina el programa (si no, puede quedar abierto por algún recurso pendiente).
            if (CERRAR_AL_TERMINAR) process.exit();
        });
}

module.exports = {
    leerTarjetas, obtenerTarjeta, extraerPromocion, leerPaginacionLocales, leerLocalesDeLista,
    firmaDeLocales, leerEstadoSelector, obtenerControl, leerOpcionesAbiertas, obtenerOpcion,
    buscarCoincidencia, crearSalida, separarSalida, limpiarPromocion,
    setZona: zona => { ZONA = zona; }
};